package shop.app;

import java.util.List;
import shop.StudentInfo;
import shop.model.PhysicalProduct;
import shop.model.Product;
import shop.payment.BankTransferPayment;
import shop.payment.CreditCardPayment;
import shop.payment.EWalletPayment;
import shop.payment.PaymentMethod;
import shop.service.CheckoutService;
import shop.service.Inventory;
import shop.shipping.ExpressShipping;
import shop.shipping.RegularShipping;
import shop.shipping.ShippingService;

/**
 * L3.f: runs six purchases one after another on the SAME stock and the SAME e-wallet,
 * so the result of one scenario affects the next. Fill the prediction columns first.
 */
public class ScenarioRunner {

    private static final Product KOPI =
            new PhysicalProduct("KOPI-001", "Kopi Arabika Gayo 250g", 85_000, 300);
    private static final Product RENDANG =
            new PhysicalProduct("RDG-002", "Rendang Kemasan 250g", 120_000, 400);
    private static final Product TEH =
            new PhysicalProduct("TEH-004", "Teh Kayu Aro 100g", 35_000, 150);

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        inventory.addStock("KOPI-001", StudentInfo.coffeeStock());
        inventory.addStock("RDG-002", StudentInfo.rendangStock());
        inventory.addStock("TEH-004", 5);

        CheckoutService checkout = new CheckoutService(inventory);
        ShippingService regular = new RegularShipping();
        EWalletPayment wallet = new EWalletPayment("DompetKu", StudentInfo.walletBalance());

        BankTransferPayment bank = new BankTransferPayment("Bank Uji");
        bank.setOnline(false); // simulated outage

        run("S1", checkout, inventory, wallet, List.of(KOPI, RENDANG), regular, wallet);
        run("S2", checkout, inventory, wallet, List.of(KOPI, KOPI, KOPI), regular, bank);
        run("S3", checkout, inventory, wallet, List.of(RENDANG, RENDANG), regular, wallet);
        run("S4", checkout, inventory, wallet, List.of(KOPI), new ExpressShipping(),
                new CreditCardPayment("Uji", 100_000));
        run("S5", checkout, inventory, wallet, List.of(), regular, wallet);
        run("S6", checkout, inventory, wallet, List.of(TEH, TEH), regular, wallet);
    }

    private static void run(String label, CheckoutService checkout, Inventory inventory,
            EWalletPayment wallet, List<Product> cart, ShippingService shipping,
            PaymentMethod payment) {
        String result;
        try {
            result = ShopApp.buy(checkout, cart, shipping, payment);
        } catch (IllegalStateException e) { // buy does not catch this one on purpose
            result = "[INVALID] " + e.getMessage();
        }
        System.out.println(label + " " + result);
        System.out.println("   stok KOPI/RDG/TEH: " + inventory.available("KOPI-001") + " / "
                + inventory.available("RDG-002") + " / " + inventory.available("TEH-004")
                + " | saldo Rp" + wallet.getBalance());
    }
}
