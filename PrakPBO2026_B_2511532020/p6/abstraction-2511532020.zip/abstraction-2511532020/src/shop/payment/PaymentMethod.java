package shop.payment;

/** Contract for every payment method. */
public interface PaymentMethod {
    String getName();
    /** @return true jika pembayaran berhasil */
    boolean pay(long amount);
}